#include<iostream>
#include<string>
#include"function/authentication.h"
using namespace std;

enum ROLE{
    CUSTOMER = 1,
    ADMIN,
    MANAGER,
    CASHIER,
};

int main(){
    while(true){
        int role = authenticateUser();
        switch(role){
            case CUSTOMER: {
                cout << "Customer functionality is not implemented yet." << endl;
                system("pause"); // Wait for user to press a key
                break;
            }
            case ADMIN: {
                cout << "Admin functionality is not implemented yet." << endl;
                system("pause");
                break;
            }
            case MANAGER: {
                cout << "Manager functionality is not implemented yet." << endl;
                system("pause");
                break;
            }
            case CASHIER: {
                cout << "Cashier functionality is not implemented yet." << endl;
                system("pause");
                break;
            }
            default: {
                cout << "Invalid choice. Please try again." << endl;
                system("pause");
                break;
            }
        }
        // Optional: Add a way to exit the loop if needed
        // char exitChoice;
        // cout << "Do you want to exit? (y/n): ";
        // cin >> exitChoice;
        // if(exitChoice == 'y' || exitChoice == 'Y') break;
    }
    return 0;
}